<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="c:/wamp/www/css/card.css">
    <link rel="stylesheet" href="c:/wamp/www/css/box.css">
    <link rel="stylesheet" href="c:/wamp/www/css/header.css">
    <link rel="stylesheet" href="c:/wamp/www/css/footer_yassa.css">
    <link rel="stylesheet" href="css/form.css">
    <link rel="stylesheet" href="bootstrap-4.4.1-dist/bootstrap-4.4.1-dist/css/bootstrap-grid.css">
    <link rel="stylesheet" href="bootstrap-4.4.1-dist/bootstrap-4.4.1-dist/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="bootstrap-4.4.1-dist/bootstrap-4.4.1-dist/css/bootstrap-grid.css.map">
    <link rel="stylesheet" href="bootstrap-4.4.1-dist/bootstrap-4.4.1-dist/css/bootstrap-reboot.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="navbarscroll.js"></script>
    <title>Traiteur du Sahel</title>

    <style>
        img {
            border-radius: 15%;
           
        }
        /* body {
            /* background-image: url('https://mdbcdn.b-cdn.net/img/new/fluid/nature/012.jpg');
            height: 100vh; */
        /* }   */
    </style>
</head>
<?php


?>

    <body>


        <header>


            <nav id="navbar_top" class="navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">
                        <button type="button" class="btn btn-light">ACCUEIL</button>



                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main_nav">
          <span class="navbar-toggler-icon"></span>
        </button>
                    <div class="collapse navbar-collapse" id="main_nav">
                        <ul class="navbar-nav ms-auto container-fluid">
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                    <button type="button" class="btn btn-light">ENTREES</button>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                    <button type="button" class="btn btn-light">

                    PLATS
                </button>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                    <button type="button" class="btn btn-light">
                DESSERTS

            </button>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                    <button type="button" class="btn btn-light">
                CONTACTS

            </button>

                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- navbar-collapse.// -->
                </div>
                <!-- container-fluid.// -->
            </nav>
        </header>



        <!-- Grid row -->

        <!-- <nav class="navbar navbar-dark bg-dark navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Navbar w/ text</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Features</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Pricing</a>
            </li>
        </ul>
        <span class="navbar-text">
        Navbar text with an inline element
      </span>
    </div>
</nav> -->
        <!-- <div class="Entrée btn bg-secondary text-white container-fluid "> ENTREE</div> -->


        <div class="corps bg-white text-black">

            <div class="row col-12">

                <div class="card col-3 border border-white  text-black">
                 
                    <h2 class="title" style="text-align: center;" >ACCRA PASTEL </h2>

                

                    <img src="Images/Acrra_Pastel.jpg" alt="ACCRA PASTEL" class="center" height="300" width="350" >
                    <p class="details" style="text-align: center;" >
                    
                    Accra à base farine et Pastel à base de farine et Poisson </p>
                   
  <h5>
  

                        <button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>

                                           <script> 
                                function myFunction() {
                                            alert(
                                               
                                                "l'Accra est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), dans certain pays, dans contrrées l'accraest est fait à base de morue");
                                                        }
                                                    
                        </script>


                    </h5>
                 
                 

                </div>
                <div class="card col-3 border border-white  text-black">

                    <h2 class="title" style="text-align: center;"  > ATIEKE POISSON</h2>
                    <img src="Images/ATIEKE.jpg" alt="Pastel Sauce Tomate" height="300" width="350" class="center">


                    <p class="details" style="text-align: center;" >coucous de manioc, sauce oignons au poisson ou au poulet, dés de tomates fraiches et bananes (ALOCO) fries..  </p>
                    <h5>
                    <button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>
                       
                       <script>    
            function myFunction() {
                        alert("l'Accra est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), dans certain pays, dans contrrées l'accraest est fait à base de morue");
                                    }
                        </script>
                     </h5>

                </div>
                <div class="card col-3 border border-white  text-black">

<h2 class="title" style="text-align: center;"  >ATIEKE POULET</h2>
<img src="Images/ATIEKE.jpg" alt="Pastel Sauce Tomate" height="300" width="350" class="center">


<p class="details" style="text-align: center;" >coucous de manioc, sauce oignons au poisson ou au poulet, dés de tomates fraiches et bananes (ALOCO) fries..  </p>
<h5>
<button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>
                       
                       <script>    
            function myFunction() {
                        alert("l'Accra est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), dans certain pays, dans contrrées l'accraest est fait à base de morue");
                                    }
    </script>
</h5>

</div>

                <div class="card col-3 border border-white text-black">

                    <h2 class="title" style="text-align: center;"> COKTAIL DE FRUITS</h2>

                    <img src="Images/fruits1.jpg" alt="Fruits" height="300" width="350" class="center">


                    <p class="details" style="text-align: center;"  >ananas, fraises, oranges, bananes..... </p>
                    <h5>
                    <button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>
                       
                       <script>    
            function myFunction() {
                        alert("l'Accra est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), dans certain pays, dans contrrées l'accraest est fait à base de morue");
                                    }
    </script>
                    </h5>

                </div>
                <div class="card col-3 border border-white text-black" style="border-radius: 25px 0 0 25px;">

                    <h2 class="title" style="text-align: center;"> THIEP DEUNE</h2>
                    <img src="Images/thieboudieun.jpg" alt="Riz au Poisson legumes avec tomates concentrées"height="300" width="350" class="center">
                    <p class="details" style="text-align: center;"  >Riz au poisson rouge ou blanc, legumes (carotte, manioc,gombo..)  </p>
                    <h5>
                    <button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>
                       
                       <script>    
            function myFunction() {
                        alert("l'Accra est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), dans certain pays, dans contrrées l'accraest est fait à base de morue");
                                    }
    </script>
                    </h5>

                </div>

            </div>
            <!-- <div class="Entrée btn bg-secondary text-white container-fluid "> PLATS</div> -->
            <div class="row col-12">

                <div class="card col-3 border border-white  text-black" style="border: bg;">

                    <h2 class="title" style="text-align: center;">Yassa au poulet </h2>

                    <img src="Images/yassa.jpg" alt="YASSA au Poulet Citron" height="300" width="350" class="center">
                    <p class="details" style="text-align: center;"  >Riz au poulet citron, avec oignons ou Riz au poisson citron avec oignons (Dorade) </p>
                    <h5>
                    <button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>
                       
                       <script>    
            function myFunction() {
                        alert("l'Accra est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), dans certain pays, dans contrrées l'accraest est fait à base de morue");
                                    }
    </script>
                    </h5>

                </div>

                <div class="card col-3 border border-white  text-black" style="border: bg;">

                    <h2 class="title" style="text-align: center;">Yassa au poisson </h2>

                    <img src="Images/yassa.jpg" alt="YASSA au Poulet Citron" height="300" width="350" class="center">
                    <p class="details" style="text-align: center;"  >Riz au poulet citron, avec oignons ou Riz au poisson citron avec oignons (Dorade) </p>
                    <h5>
                    <button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>
                       
                       <script>    
            function myFunction() {
                        alert("l'Accra est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), dans certain pays, dans contrrées l'accraest est fait à base de morue");
                                    }
    </script>
                    </h5>

                </div>

                <div class="card col-3 border border-white text-black">

                    <h2 class="title" style="text-align: center;"> Riz à la viande et Sauce arachide - Mafé</h2>
                    <img src="Images/Mafé1.jpg" alt="Mafé" height="300" width="350" class="center">


                    <pclass="details" style="text-align: center;"   >Riz à la vidande agneau ou boeuf, sauce à la pate d'arachide, et légumes (carotte, manioc,gombo..) </p>
                    <h5>
                    <button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>
                       
                       <script>    
            function myFunction() {
                        alert("l'Accra est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), dans certain pays, dans contrrées l'accraest est fait à base de morue");
                                    }
    </script>
                    </h5>

                </div>
                <div class="card col-3 border border-white  text-black">

                    <h2 class="title" style="text-align: center;">Riz à la viande et Sauce Tomate - Thiou</h2>

                    <img src="Images/thiou.jpg" alt="" height="300" width="350" class="center">


                    <p class="details" style="text-align: center;"  >Riz à la viande agneau ou boeuf, avec oignons et corottes en rondelles</p>
                    <h5>
                    <button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>
                       
                       <script>    
            function myFunction() {
                        alert("l'Accra est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), dans certain pays, dans contrrées l'accraest est fait à base de morue");
                                    }
    </script>
                    </h5>

                </div>
                <div class="card col-3 border border-white text-black">

                    <h2 class="title" style="text-align: center;"> Riz au poisson - Thiep dieune</h2>
                    <img src="Images/thieboudieun.jpg" alt="Riz au poisson manioc carottes..." height="300" width="350" class="center">
                    <p class="details" style="text-align: center;"  >pour plus de détails </p>
                    <h5>
                    <button type="button" onclick="myFunction()" class="btn btn-info" > allez plus loin...</button>
                       
                       <script>    
            function myFunction() {
                        alert("l'Accara est un plat d'origine du Dhaomey (atuel Benin, elle est faite d'origine avec le Niebé (haricot blanc), Vigna unguiculata ou niébé est une espèce de plantes de la famille des Fabaceae et du genre Vigna originaire d'Afrique tropicale, dont plusieurs sous-espèces sont cultivées comme plantes alimentaires pour leurs graines, proches des haricots, ou pour leur gousses. C'est la principale légumineuse alimentaire d'Afrique tropicale, fournissant une source de protéines de grande qualité . Le Nigeria est le premier producteur mondial de niébé, dans d'autres endroits l'accra est est fait à base de morue");
                                    }
    </script>
                    </h5>

                </div>




            </div>

        </div>
        <!-- Grid row -->

        <!-- <div class="Entrée btn bg-secondary text-white container-fluid "> DESSERTS</div> -->
        <div class="commande row col-12">

            <div class="form col-6">
                <form method="POST" action="traitement.php" class="container-fluid" style="border-radius:8px;">

                    <button class="btn btn-info">
                <h7> Votre choix     <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-bag-dash-fill" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5v-.5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0zM6 9.5a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1H6z"/>
                  </svg></h7>

            </button>

            <div class="input-group">
  <div class="input-group-prepend" placeholder="CLIQUER SUR VOTRE PLAT PREFERE">
    <!-- <span class="input-group-text"></span> -->
  </div>
  <textarea class="form-control text-light bg-dark" aria-label="With textarea"   >         CLIQUER SUR VOTRE PLAT PREFERE" </textarea>
</div>
                    <!-- <input type="text" class="btn btn-secondary text-white" placeholder="Votre plat préféré"> -->
                    <label for="">Prenom</label>
                    <input type="text" name="prenom" placeholder="votre prenom">
                    <label for="">nom</label>
                    <input type="text" name="nom">
                    <label for="">E-mail</label>
                    <input type="email" id="emailField" name="emailField" placeholder="votre e-mail">
                    <label for="">date</label>
                    <input type="date" name="date">
                    <label for="">Telephone</label>
                    <input type="tel" id="telField" name="telField">
                    <input type="submit" value="Envoyer" class="btn btn-info">

                </form>

            </div>


        </div>
        <!-- </div> -->

        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                window.addEventListener('scroll', function() {
                    if (window.scrollY > 50) {
                        document.getElementById('navbar_top').classList.add('fixed-top');
                        // add padding top to show content behind navbar
                        navbar_height = document.querySelector('.navbar').offsetHeight;
                        document.body.style.paddingTop = navbar_height + 'px';
                    } else {
                        document.getElementById('navbar_top').classList.remove('fixed-top');
                        // remove padding top from body
                        document.body.style.paddingTop = '0';
                    }
                });
            });
        </script>


        <footer class="bg-dark">
            <a href="#" class="text-light">
                <h5 class="contact" style="text-align: center;">
                    Contact : falzofaye@gmail.com mobile 06 29 89 98 21
                </h5>

        </footer>
    </body>

</html>

<!-- 
    grid-column