<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Traitement des données envoyées par formulaire</title>
</head>


<body>
<?php

$con = mysqli_connect("localhost","root","");// connection au serveur
mysqli_select_db($con, "sahel"); // connection à la base de données

if (mysqli_select_db($con, "sahel"))
{
    echo "connexion reussie";
}

else {
    echo  " vous n'etes pas connecté";
}

?>



<p> Bonjour <?php       
echo$_POST['prenom']; echo' ';
echo$_POST['nom'];   

    
?></p>

<p> votre e-mail est  :  <?php echo $_POST['emailField']  ?>
</p>
<p> vous avez réservé pour cette date :  <?php echo $_POST['date']  ?>
</p>

<p> Votre mobile est :                   <?php echo $_POST['telField'];?>

</p>  

</body>
</html>

